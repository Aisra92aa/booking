
// trips-data.js
const trips = [
  {
    id: 1,
    title: "رحلة إلى البتراء",
    date: "2025-08-20",
    price: "40 دينار",
    duration: "يوم واحد",
    description: "استمتع بجولة تاريخية في مدينة البتراء الوردية.",
    image: "images/petra.jpg"
  },
  {
    id: 2,
    title: "رحلة إلى العقبة",
    date: "2025-08-25",
    price: "35 دينار",
    duration: "يومين",
    description: "استمتع بالشواطئ الساحرة والأنشطة البحرية في العقبة.",
    image: "images/aqaba.jpg"
  },
  {
    id: 3,
    title: "رحلة إلى جرش",
    date: "2025-09-01",
    price: "20 دينار",
    duration: "نصف يوم",
    description: "تعرف على تاريخ الحضارة الرومانية في مدينة جرش.",
    image: "images/jerash.jpg"
  }
];
